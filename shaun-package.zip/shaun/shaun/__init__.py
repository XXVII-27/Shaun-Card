__app_name__ = 'shaun'
__version__ = '0.1.0'
